export const RECENT_TABS_MASTER_ID = "igpepgofglnhfpmgbcjkndcfjemhoaac"; 
export const RECENT_TABS_FORWARD_ID = "dpnndineanlmfogoccoffnbljfcpebol"; 
export const RECENT_TABS_FAST_FORWARD_ID = "kdiokjemgpcccpfemfcbkhfddjjmipfb";



